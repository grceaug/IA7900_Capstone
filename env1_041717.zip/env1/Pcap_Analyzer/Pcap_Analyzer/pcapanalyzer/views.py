from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage


#from django.http.response import HttpResponseRedirect


def index(request):
    progress = 0
    #print "printing dictionary" %request.GET.get()
    if(request.POST.get('Analyzebtn')):
        progress = 5
        
#        myfile = request.FILES['myfile']
#        print myfile 
        
        if len(request.FILES) != 0: 
#            if (request.FILES['myfile']):
            myfile = request.FILES['myfile']
            fs = FileSystemStorage()
            filename = fs.save(myfile.name, myfile)
            uploaded_file_url = fs.url(filename)
            progress = 10        
            return render(request, 'pcapanalyzer/home.html', { "progress": progress, 'uploaded_file_url': uploaded_file_url})
        else:
            message1 = "-danger"
            message2 = "Error !! Please select a Pcap file to load."            
            return render(request, 'pcapanalyzer/home.html',  {"message1": message1 , "message2" : message2} )
    
    if(request.POST.get('cancelbtn')):
        progress = 0
        return render(request, 'pcapanalyzer/home.html', { "progress": progress})    

    return render(request, 'pcapanalyzer/home.html')

#def nofiles(request):
#    return render(request, 'pcapanalyzer/nofile.html')
    
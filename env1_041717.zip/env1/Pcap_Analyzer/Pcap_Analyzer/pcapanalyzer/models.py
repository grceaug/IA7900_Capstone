from django.db import models

class Control(models.Model):
    date = models.DateTimeField()
    file = models.CharField(max_length = 200)
    protocol = models.TextField()
    status = models.TextField()
    

    def __unicode__(self):
        return self.date, self.status
